﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BLind.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public ActionResult Test()
        {
            return View();
        }
        public ActionResult KinhCan()
        {
            return View();
        }
        public ActionResult KinhRam()
        {
            return View();
        }
        public ActionResult PhuKien()
        {
            return View();
        }
        public ActionResult VeChungToi()
        {
            return View();
        }
        public ActionResult THECLASSICS()
        {
            return View();
        }
        public ActionResult THEMETAL()
        {
            return View();
        }
        public ActionResult THELAYERED()
        {
            return View();
        }

        public ActionResult CHINHSACH()
        {
            return View();
        }
        public ActionResult DOITRA()
        {
            return View();
        }
        public ActionResult TrangChu()
        {
            return View();
        }

        public ActionResult CUAHANG()
        {
            return View();

        }
       
        public ActionResult Login()
        {
            return View();
        }
        public ActionResult Register()
        {
            return View();
        }
        public ActionResult ThanhToan()
        {
            return View();

        }
        public ActionResult GioHang()
        {
            return View();
        }
        public ActionResult Yoon()
        {
            return View();
        }











    }
}